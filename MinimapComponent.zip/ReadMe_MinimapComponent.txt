READ ME
.......
1/31/2011
.......

Requirements for development:

    * XNA 3.1 Game Studio
    * Visual C# 2008 (any edition, including Express)
    * Vista, or Windows 7
    * Internet connection
    * Copy of TemporalWars 3D Game Engine.

1) Extract the 'MinimapInterfaces.zip' and 'MinimapComponentLibrary.zip' files to the 'Projects' folder within your version of Visual Studios.
2) Open up the 'MinimapInterfaces.sln' and 'MinimapComponentLibrary.sln' files in Visual Studios.
3) When asked about 'Source Control', choose to "permanently remove".
4) Compile either the x86 or Xbox360 version of the Minimap Late-Bind component.
5) To use, copy ONLY the assembly file 'RTS_MinimapComponentLibrary.dll' to the '0LateBinds' folder within your copy of TemporalWars 3D Game engine, and set the property "Copy to Output Directory" to 'Copy Always'.


Ben
Image-Nexus, LLC.
www.temporalwars.com

